﻿
using System;
using System.Collections.Generic;
using System.Windows.Forms;
using CybersecurityGUI;

namespace CybersecurityChatbot
{
    public partial class Form1 : Form
    {
        private List<TaskItem> tasks = new List<TaskItem>();
        private List<string> activityLog = new List<string>();
        private int quizIndex = 0;
        private int quizScore = 0;
        private List<QuizQuestion> quizQuestions;

        // --- Conversation State for task reminder flow ---
        private enum ConversationState
        {
            None,
            WaitingForReminderConfirmation,
            WaitingForReminderTime
        }

        private ConversationState currentState = ConversationState.None;
        private string pendingTaskDescription = null;

        public Form1()
        {
            InitializeComponent();
            InitializeQuiz();
        }

        // === CHATBOT LOGIC with task reminder flow ===
        private void btnSend_Click(object sender, EventArgs e)
        {
            string input = txtChatInput.Text.Trim();
            string inputLower = input.ToLower();
            txtChatHistory.AppendText($"You: {input}\n");
            txtChatInput.Clear();

            switch (currentState)
            {
                case ConversationState.None:
                    if (inputLower.StartsWith("add task -"))
                    {
                        // Extract task description after "add task -"
                        pendingTaskDescription = input.Substring(10).Trim();

                        // Add task immediately with description
                        var newTask = new TaskItem
                        {
                            Title = pendingTaskDescription,
                            Description = pendingTaskDescription,
                            Completed = false
                        };
                        tasks.Add(newTask);
                        lstTasks.Items.Add(newTask);
                        Log($"Task added: {pendingTaskDescription}");

                        txtChatHistory.AppendText($"Bot: Task added with the description \"{pendingTaskDescription}\". Would you like a reminder?\n");
                        currentState = ConversationState.WaitingForReminderConfirmation;
                    }
                    else if (inputLower.Contains("add task") || inputLower.Contains("remind"))
                    {
                        // Just switch to Task tab for manual adding
                        tabControl.SelectedTab = tabTasks;
                        txtChatHistory.AppendText("Bot: I switched you to the Task tab to add or manage your tasks.\n");
                        Log("Switched to Task Assistant due to NLP command.");
                    }
                    else if (inputLower.Contains("quiz"))
                    {
                        tabControl.SelectedTab = tabQuiz;
                        txtChatHistory.AppendText("Bot: Starting the cybersecurity quiz!\n");
                        Log("User started quiz via NLP command.");
                    }
                    else if (inputLower.Contains("log") || inputLower.Contains("what have you done"))
                    {
                        tabControl.SelectedTab = tabLog;
                        txtChatHistory.AppendText("Bot: Showing recent activity log.\n");
                        Log("User viewed activity log via NLP.");
                    }
                    else
                    {
                        // Default responses
                        if (inputLower.Contains("worried") || inputLower.Contains("frustrated"))
                            txtChatHistory.AppendText("Bot: I understand how you feel. Cybersecurity can be tricky, but I'm here to help!\n");
                        else if (inputLower.Contains("password"))
                            txtChatHistory.AppendText("Bot: Use strong, unique passwords and enable 2FA where possible.\n");
                        else if (inputLower.Contains("phishing"))
                            txtChatHistory.AppendText("Bot: Don’t click suspicious links. Always verify senders.\n");
                        else
                            txtChatHistory.AppendText("Bot: I didn't quite get that. Try asking about passwords, scams, or privacy.\n");
                    }
                    break;

                case ConversationState.WaitingForReminderConfirmation:
                    // Check if user wants reminder
                    if (inputLower.StartsWith("yes"))
                    {
                        txtChatHistory.AppendText("Bot: When would you like me to remind you? For example, 'in 3 days' or 'in 2 hours'.\n");
                        currentState = ConversationState.WaitingForReminderTime;
                    }
                    else
                    {
                        txtChatHistory.AppendText("Bot: Okay, no reminder set.\n");
                        currentState = ConversationState.None;
                        pendingTaskDescription = null;
                    }
                    break;

                case ConversationState.WaitingForReminderTime:
                    // Parse time from input, simple pattern like "in 3 days", "in 2 hours"
                    DateTime? reminderTime = ParseReminderTime(inputLower);
                    if (reminderTime.HasValue)
                    {
                        // Find the last task added with pendingTaskDescription
                        var task = tasks.FindLast(t => t.Title == pendingTaskDescription);
                        if (task != null)
                        {
                            task.Reminder = reminderTime;
                            // Refresh listbox item - simplest way: clear and re-add all (or implement better binding)
                            int idx = lstTasks.Items.IndexOf(task);
                            if (idx != -1)
                            {
                                lstTasks.Items[idx] = task;  // Refresh display
                            }
                            Log($"Reminder set for task '{task.Title}' at {reminderTime}");
                        }

                        // Confirm to user
                        TimeSpan diff = reminderTime.Value - DateTime.Now;
                        string friendlyTime = FriendlyTimeSpan(diff);

                        txtChatHistory.AppendText($"Bot: Got it! I'll remind you {friendlyTime}.\n");

                        currentState = ConversationState.None;
                        pendingTaskDescription = null;
                    }
                    else
                    {
                        txtChatHistory.AppendText("Bot: Sorry, I didn't understand the reminder time. Please say something like 'in 3 days' or 'in 2 hours'.\n");
                    }
                    break;
            }
        }

        // === TASK ASSISTANT ===
        private void btnAddTask_Click(object sender, EventArgs e)
        {
            string title = txtTaskTitle.Text.Trim();
            string desc = txtTaskDesc.Text.Trim();
            DateTime? reminder = chkReminder.Checked ? (DateTime?)dtpReminder.Value : null;

            if (string.IsNullOrEmpty(title))
            {
                MessageBox.Show("Task title cannot be empty.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            var task = new TaskItem { Title = title, Description = desc, Reminder = reminder, Completed = false };
            tasks.Add(task);

            lstTasks.Items.Add(task);
            Log($"Task added: {title}{(reminder.HasValue ? $" (Reminder: {reminder.Value})" : "")}");
            ClearTaskInputs();
        }

        private void btnDeleteTask_Click(object sender, EventArgs e)
        {
            if (lstTasks.SelectedItem is TaskItem task)
            {
                tasks.Remove(task);
                lstTasks.Items.Remove(task);
                Log($"Task deleted: {task.Title}");
            }
        }

        private void ClearTaskInputs()
        {
            txtTaskTitle.Clear();
            txtTaskDesc.Clear();
            chkReminder.Checked = false;
            dtpReminder.Value = DateTime.Now;
        }

        // === QUIZ ===
        private void InitializeQuiz()
        {
            quizQuestions = QuizQuestion.GetSampleQuestions();
            quizIndex = 0;
            quizScore = 0;
            lblFeedback.Text = "";
            ShowNextQuizQuestion();
        }

        private void ShowNextQuizQuestion()
        {
            if (quizIndex >= quizQuestions.Count)
            {
                lblQuiz.Text = $"Quiz Complete! You scored {quizScore} out of {quizQuestions.Count}.";
                Log($"Quiz completed. Score: {quizScore}/{quizQuestions.Count}");
                lstQuizOptions.Enabled = false;
                btnNextQuestion.Enabled = false;
                btnStartQuiz.Enabled = true;
                return;
            }

            var q = quizQuestions[quizIndex];
            lblQuiz.Text = q.Question;
            lstQuizOptions.Items.Clear();
            foreach (var opt in q.Options)
                lstQuizOptions.Items.Add(opt);

            lstQuizOptions.Enabled = true;
            btnNextQuestion.Enabled = true;
            btnStartQuiz.Enabled = false;
            lblFeedback.Text = "";
        }

        private void btnStartQuiz_Click(object sender, EventArgs e)
        {
            InitializeQuiz();
        }

        private void btnNextQuestion_Click(object sender, EventArgs e)
        {
            if (lstQuizOptions.SelectedIndex == -1)
            {
                MessageBox.Show("Please select an answer before proceeding.", "No Answer Selected", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            var selected = lstQuizOptions.SelectedItem.ToString();
            var q = quizQuestions[quizIndex];

            if (selected == q.Answer)
            {
                quizScore++;
                lblFeedback.Text = "Correct! " + q.Feedback;
            }
            else
            {
                lblFeedback.Text = "Incorrect. " + q.Feedback;
            }

            quizIndex++;
            ShowNextQuizQuestion();
        }

        // === ACTIVITY LOG ===
        private void Log(string message)
        {
            activityLog.Insert(0, $"[{DateTime.Now:HH:mm}] {message}");
            if (activityLog.Count > 10)
                activityLog.RemoveAt(activityLog.Count - 1);

            lstLog.Items.Clear();
            foreach (var entry in activityLog)
                lstLog.Items.Add(entry);
        }

        // === Helper to parse reminder time from input like "in 3 days" ===
        private DateTime? ParseReminderTime(string input)
        {
            // Expect input like "in 3 days", "in 2 hours", "in 45 minutes"
            input = input.ToLower().Trim();

            if (!input.StartsWith("in "))
                return null;

            string[] parts = input.Substring(3).Split(' ');

            if (parts.Length != 2)
                return null;

            if (!int.TryParse(parts[0], out int value))
                return null;

            string unit = parts[1];
            DateTime now = DateTime.Now;

            if (unit.StartsWith("day"))
                return now.AddDays(value);
            else if (unit.StartsWith("hour"))
                return now.AddHours(value);
            else if (unit.StartsWith("minute"))
                return now.AddMinutes(value);

            return null;
        }

        // Friendly string from TimeSpan for confirmation messages
        private string FriendlyTimeSpan(TimeSpan span)
        {
            if (span.TotalDays >= 1)
                return $"in {Math.Round(span.TotalDays)} days";
            if (span.TotalHours >= 1)
                return $"in {Math.Round(span.TotalHours)} hours";
            if (span.TotalMinutes >= 1)
                return $"in {Math.Round(span.TotalMinutes)} minutes";

            return "soon";
        }
    }

    // === TaskItem class ===
    public class TaskItem
    {
        public string Title { get; set; }
        public string Description { get; set; }
        public DateTime? Reminder { get; set; }
        public bool Completed { get; set; }

        public override string ToString()
        {
            return $"{Title}{(Reminder.HasValue ? $" (Reminder: {Reminder.Value:g})" : "")}{(Completed ? " [Done]" : "")}";
        }
    }

    // === QuizQuestion class ===
    public class QuizQuestion
    {
        public string Question { get; set; }
        public List<string> Options { get; set; }
        public string Answer { get; set; }
        public string Feedback { get; set; }

        public static List<QuizQuestion> GetSampleQuestions()
        {
            return new List<QuizQuestion>
            {
                new QuizQuestion
                {
                    Question = "What is phishing?",
                    Options = new List<string> { "A cyber attack using fraudulent emails", "A type of password", "A security software", "A programming language" },
                    Answer = "A cyber attack using fraudulent emails",
                    Feedback = "Phishing is a scam to get sensitive information."
                },
                new QuizQuestion
                {
                    Question = "Which one is a strong password?",
                    Options = new List<string> { "123456", "password", "P@ssw0rd!23", "abcdef" },
                    Answer = "P@ssw0rd!23",
                    Feedback = "Strong passwords use letters, numbers, and symbols."
                }
                // Add more questions as needed...
            };
        }
    }
}

