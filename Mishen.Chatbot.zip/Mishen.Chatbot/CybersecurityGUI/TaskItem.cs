﻿using System;

namespace CybersecurityGUI
{
    public class TaskItem
    {
        public string Title { get; set; }
        public string Description { get; set; }
        public DateTime? Reminder { get; set; }
        public bool Completed { get; set; }

        public override string ToString()
        {
            string reminderStr = Reminder.HasValue ? $" (Reminder: {Reminder.Value:g})" : "";
            string status = Completed ? "[Done] " : "";
            return $"{status}{Title}{reminderStr}";
        }
    }
}
