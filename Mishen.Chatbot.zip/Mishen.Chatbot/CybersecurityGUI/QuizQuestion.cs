﻿using System.Collections.Generic;

namespace CybersecurityGUI
{
    public class QuizQuestion
    {
        public string Question { get; set; }
        public List<string> Options { get; set; }
        public string Answer { get; set; }
        public string Feedback { get; set; }

        public static List<QuizQuestion> GetSampleQuestions()
        {
            return new List<QuizQuestion>
            {
                new QuizQuestion
                {
                    Question = "What does 2FA stand for?",
                    Options = new List<string> { "Two-Factor Authentication", "Two-Face Authorization", "Two-Form Access", "Twice Fast Approval" },
                    Answer = "Two-Factor Authentication",
                    Feedback = "2FA means you need two forms of verification to log in, adding extra security."
                },
                new QuizQuestion
                {
                    Question = "Which of these is a strong password?",
                    Options = new List<string> { "password123", "MyBirthDate", "7h!sIs$tr0ng", "123456" },
                    Answer = "7h!sIs$tr0ng",
                    Feedback = "Strong passwords combine letters, numbers, and symbols."
                },
                new QuizQuestion
                {
                    Question = "What is phishing?",
                    Options = new List<string> { "Fishing in the ocean", "Fake emails to steal data", "Secure data encryption", "A cybersecurity protocol" },
                    Answer = "Fake emails to steal data",
                    Feedback = "Phishing involves tricking users into revealing sensitive info via fake emails or sites."
                }
            };
        }
    }
}
